import java.util.ArrayList;
import java.util.List;

public class BlueRayDisc {

    private String title;
    private String discId;
    private Directory rootDirectory;

    public BlueRayDisc(String title, String discId) {
        this.title = title;
        this.discId = discId;
        this.rootDirectory = new Directory("/", null);
    }

    public String getTitle() {
        return title;
    }

    public String getDiscId() {
        return discId;
    }

    public Directory getRootDirectory() {
        return rootDirectory;
    }

    public static class Directory {
        private String name;
        private Directory parent;
        private List<Directory> subdirectories;
        private List<Entry> entries;

        public Directory(String name, Directory parent) {
            this.name = name;
            this.parent = parent;
            this.subdirectories = new ArrayList<>();
            this.entries = new ArrayList<>();
        }

        public String getName() {
            return name;
        }

        public Directory getParent() {
            return parent;
        }

        public List<Directory> getSubdirectories() {
            return subdirectories;
        }

        public List<Entry> getEntries() {
            return entries;
        }

        public void addSubdirectory(Directory subdirectory) {
            subdirectories.add(subdirectory);
        }

        public void addEntry(Entry entry) {
            entries.add(entry);
        }
    }

    public static class Entry {
        private String name;
        private String type; // "movie", "music", "photo", etc.
        private long sizeInBytes;

        public Entry(String name, String type, long sizeInBytes) {
            this.name = name;
            this.type = type;
            this.sizeInBytes = sizeInBytes;
        }

        public String getName() {
            return name;
        }

        public String getType() {
            return type;
        }

        public long getSizeInBytes() {
            return sizeInBytes;
        }
    }

    public static void main(String[] args) {
        BlueRayDisc disc = new BlueRayDisc("Movie Collection", "BR19929");

        Directory movies = new Directory("Movies", disc.getRootDirectory());
        Directory action = new Directory("Action", movies);
        Directory comedy = new Directory("Comedy", movies);

        disc.getRootDirectory().addSubdirectory(movies);
        movies.addSubdirectory(action);
        movies.addSubdirectory(comedy);

        Entry theMatrix = new Entry("ЯЛегенда", "movie", 1024 * 1024 * 1024);
        Entry dieHard = new Entry("Трон", "movie", 800 * 1024 * 1024);
        Entry theHangover = new Entry("Падингтон", "movie", 950 * 1024 * 1024);

        action.addEntry(theMatrix);
        action.addEntry(dieHard);
        comedy.addEntry(theHangover);

        System.out.println("Title: " + disc.getTitle());
        System.out.println("Disc ID: " + disc.getDiscId());

        System.out.println("\nDirectory Structure:");
        printDirectoryStructure(disc.getRootDirectory(), "");
    }

    private static void printDirectoryStructure(Directory directory, String indent) {
        System.out.println(indent + directory.getName());
        for (Directory subdirectory : directory.getSubdirectories()) {
            printDirectoryStructure(subdirectory, indent + "  ");
        }
        for (Entry entry : directory.getEntries()) {
            System.out.println(indent + "  " + entry.getName() + " (" + entry.getType() + ")");
        }
    }
}
