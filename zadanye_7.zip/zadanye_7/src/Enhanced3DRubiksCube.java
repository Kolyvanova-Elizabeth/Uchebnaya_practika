import javax.swing.*;
import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;

public class Enhanced3DRubiksCube extends JPanel {

    private static final int TILE_SIZE = 50;   // Размер каждой плитки
    private static final int PADDING = 4;      // Отступ между плитками

    private static final TexturePaint[] PATTERNS = {
            createPattern(Color.BLACK, Color.WHITE, 10),     // Черный с белыми точками
            createPattern(Color.WHITE, Color.BLACK, 10),     // Белый с черными точками
            createPattern(Color.DARK_GRAY, Color.LIGHT_GRAY, 10), // Серый с черными точками
            createPattern(Color.LIGHT_GRAY, Color.DARK_GRAY, 15), // Светло-серый с черными точками
            createPattern(Color.BLACK, Color.GRAY, 5)        // Черный с серыми точками
    };

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        drawFace(g2d, 150, 150, TILE_SIZE, 0); // Передняя грань
        drawFace(g2d, 120, 110, TILE_SIZE, 1); // Верхняя грань (светлее для эффекта объема)
        drawFace(g2d, 190, 110, TILE_SIZE, 2); // Правая грань (темнее для эффекта объема)
    }
    private void drawFace(Graphics2D g2d, int startX, int startY, int tileSize, int faceType) {
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 3; col++) {
                int x = startX + col * (tileSize + PADDING);
                int y = startY + row * (tileSize + PADDING);
                if (faceType == 1) { // Верхняя грань
                    x -= col * 10;
                    y -= row * 10;
                } else if (faceType == 2) { // Правая грань
                    x += col * 10;
                    y -= row * 10;
                }
                g2d.setPaint(PATTERNS[(row + col) % PATTERNS.length]);
                g2d.fill(new Rectangle2D.Double(x, y, tileSize, tileSize));
                g2d.setColor(Color.BLACK);
                g2d.setStroke(new BasicStroke(2));
                g2d.draw(new Rectangle2D.Double(x, y, tileSize, tileSize));

                if (faceType == 1) { // Тень для верхней грани (светлее)
                    g2d.setColor(new Color(220, 220, 220, 120));
                } else if (faceType == 2) { // Тень для правой грани (темнее)
                    g2d.setColor(new Color(0, 0, 0, 80));
                } else {
                    g2d.setColor(new Color(100, 100, 100, 80));
                }
                g2d.fillRect(x + tileSize - 5, y + tileSize - 5, 10, 10); // Угловая тень
            }
        }
    }
    private static TexturePaint createPattern(Color color1, Color color2, int size) {
        BufferedImage bi = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = bi.createGraphics();
        g2.setColor(color1);
        g2.fillRect(0, 0, size, size);
        g2.setColor(color2);
        for (int i = 0; i < size; i += 4) {
            for (int j = 0; j < size; j += 4) {
                g2.fillRect(i, j, 2, 2);
            }
        }
        g2.dispose();
        return new TexturePaint(bi, new Rectangle(0, 0, size, size));
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Enhanced 3D Rubik's Cube");
        Enhanced3DRubiksCube cubePanel = new Enhanced3DRubiksCube();
        frame.add(cubePanel);
        frame.setSize(400, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
