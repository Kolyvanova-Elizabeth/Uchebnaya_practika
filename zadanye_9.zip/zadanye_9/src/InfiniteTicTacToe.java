import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;

public class InfiniteTicTacToe extends JFrame {
    private int gridSize = 5; // Начальный размер сетки
    private char currentPlayer = 'X'; // 'X' ходит первым
    private Map<Point, JButton> board = new HashMap<>();
    private boolean vsComputer = false; // Режим против компьютера

    public InfiniteTicTacToe() {
        setTitle("Крестики-Нолики на бесконечном поле");
        setSize(700, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Color mintGreen = new Color(189, 236, 182); // Нежно-мятный
        Color softPink = new Color(255, 210, 224);  // Нежно-розовый

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.setBackground(mintGreen);
        JPanel gamePanel = new JPanel(new GridLayout(gridSize, gridSize));
        mainPanel.add(gamePanel, BorderLayout.CENTER);
        gamePanel.setBackground(mintGreen);
        fillBoard(gamePanel, softPink);
        JPanel controlPanel = new JPanel();
        controlPanel.setBackground(mintGreen);
        JButton newGameButton = new JButton("Новая Игра");
        JButton playerVsPlayerButton = new JButton("2 Игрока");
        JButton playerVsComputerButton = new JButton("Против Компьютера");
        setupButtonStyle(newGameButton, mintGreen, softPink);
        setupButtonStyle(playerVsPlayerButton, mintGreen, softPink);
        setupButtonStyle(playerVsComputerButton, mintGreen, softPink);

        controlPanel.add(newGameButton);
        controlPanel.add(playerVsPlayerButton);
        controlPanel.add(playerVsComputerButton);

        mainPanel.add(controlPanel, BorderLayout.SOUTH);
        add(mainPanel);
        newGameButton.addActionListener(e -> resetGame(gamePanel, softPink));
        playerVsPlayerButton.addActionListener(e -> {
            vsComputer = false;
            resetGame(gamePanel, softPink);
        });
        playerVsComputerButton.addActionListener(e -> {
            vsComputer = true;
            resetGame(gamePanel, softPink);
            if (vsComputer && currentPlayer == 'O') {
                computerMove();
            }
        });

        setVisible(true);
    }

    private void setupButtonStyle(JButton button, Color background, Color foreground) {
        button.setFont(new Font("Serif", Font.BOLD, 20));
        button.setBackground(foreground);
        button.setForeground(Color.BLACK);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
    }

    private void fillBoard(JPanel gamePanel, Color softPink) {
        gamePanel.removeAll();
        board.clear();
        gamePanel.setLayout(new GridLayout(gridSize, gridSize));

        for (int row = 0; row < gridSize; row++) {
            for (int col = 0; col < gridSize; col++) {
                JButton button = new JButton("");
                button.setFont(new Font("Serif", Font.BOLD, 30)); // Красивый шрифт
                button.setBackground(softPink); // Нежно-розовый фон
                button.setFocusPainted(false);
                button.setBorder(new LineBorder(Color.BLACK, 1)); // Черная граница для создания сетки
                button.addActionListener(new ButtonClickListener(row, col));
                board.put(new Point(row, col), button);
                gamePanel.add(button);
            }
        }

        gamePanel.revalidate();
        gamePanel.repaint();
    }

    private void resetGame(JPanel gamePanel, Color softPink) {
        currentPlayer = 'X';
        gridSize = 5;
        fillBoard(gamePanel, softPink);
    }
    private class ButtonClickListener implements ActionListener {
        private final int row;
        private final int col;

        public ButtonClickListener(int row, int col) {
            this.row = row;
            this.col = col;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            JButton button = (JButton) e.getSource();
            if (!button.getText().equals("")) return; // Ячейка уже занята

            button.setText(String.valueOf(currentPlayer));
            if (checkWin(row, col)) {
                JOptionPane.showMessageDialog(null, "Игрок " + currentPlayer + " выиграл!");
                resetGame((JPanel) getContentPane().getComponent(0), new Color(255, 210, 224));
                return;
            }

            currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';

            if (vsComputer && currentPlayer == 'O') {
                computerMove();
            }

            if (isBorderFilled()) {
                expandBoard((JPanel) getContentPane().getComponent(0));
            }
        }
    }
    private boolean checkWin(int row, int col) {
        String symbol = String.valueOf(currentPlayer);
        return (checkLine(row, 0, 0, 1, symbol) ||  // Проверка строки
                checkLine(0, col, 1, 0, symbol) ||  // Проверка столбца
                checkLine(0, 0, 1, 1, symbol) ||    // Диагональ слева направо
                checkLine(0, gridSize - 1, 1, -1, symbol)); // Диагональ справа налево
    }

    private boolean checkLine(int startRow, int startCol, int rowIncrement, int colIncrement, String symbol) {
        for (int i = 0; i < gridSize; i++) {
            JButton button = board.get(new Point(startRow + i * rowIncrement, startCol + i * colIncrement));
            if (button == null || !button.getText().equals(symbol)) {
                return false;
            }
        }
        return true;
    }

    private boolean isBorderFilled() {
        for (int i = 0; i < gridSize; i++) {
            if (board.get(new Point(0, i)).getText().equals("") ||
                    board.get(new Point(gridSize - 1, i)).getText().equals("") ||
                    board.get(new Point(i, 0)).getText().equals("") ||
                    board.get(new Point(i, gridSize - 1)).getText().equals("")) {
                return false;
            }
        }
        return true;
    }

    private void expandBoard(JPanel gamePanel) {
        gridSize += 2;
        fillBoard(gamePanel, new Color(255, 210, 224));
    }

    private void computerMove() {
        for (Map.Entry<Point, JButton> entry : board.entrySet()) {
            JButton button = entry.getValue();
            if (button.getText().equals("")) {
                button.setText(String.valueOf(currentPlayer));
                currentPlayer = 'X';
                return;
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(InfiniteTicTacToe::new);
    }
}
