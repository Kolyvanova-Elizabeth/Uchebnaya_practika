import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

class Flight {
    private String flightNumber;
    private String destination;
    private int capacity;

    public Flight(String flightNumber, String destination, int capacity) throws InvalidFlightNumberException {
        if (!flightNumber.matches("^[A-Z]{2}\\d{3}$")) {
            throw new InvalidFlightNumberException("Недопустимый номер рейса: " + flightNumber);
        }
        this.flightNumber = flightNumber;
        this.destination = destination;
        this.capacity = capacity;
    }

    public String getFlightNumber() {
        return flightNumber;
    }

    public String getDestination() {
        return destination;
    }

    public int getCapacity() {
        return capacity;
    }

    @Override
    public String toString() {
        return "Рейс: " + flightNumber + ", Направление: " + destination + ", Вместимость: " + capacity;
    }
}

class InvalidFlightNumberException extends Exception {
    public InvalidFlightNumberException(String message) {
        super(message);
    }
}

class InsufficientMemoryException extends Exception {
    public InsufficientMemoryException(String message) {
        super(message);
    }
}

class FileNotFoundCustomException extends Exception {
    public FileNotFoundCustomException(String message) {
        super(message);
    }
}

class Airline {
    private List<Flight> flights;

    public Airline() {
        flights = new ArrayList<>();
    }

    public void addFlight(Flight flight) throws InsufficientMemoryException {
        if (flights.size() >= 100) { // Предположим, что максимальное количество рейсов - 100
            throw new InsufficientMemoryException("Недостаточно памяти для добавления рейса.");
        }
        flights.add(flight);
    }

    public List<Flight> getFlights() {
        return flights;
    }

    public void saveToFile(String filename) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
            for (Flight flight : flights) {
                writer.write(flight.toString());
                writer.newLine();
            }
        }
    }

    public void loadFromFile(String filename) throws FileNotFoundCustomException, IOException {
        File file = new File(filename);
        if (!file.exists()) {
            throw new FileNotFoundCustomException("Файл не найден: " + filename);
        }
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(", ");
                String flightNumber = parts[0].split(": ")[1];
                String destination = parts[1].split(": ")[1];
                int capacity = Integer.parseInt(parts[2].split(": ")[1]);
                flights.add(new Flight(flightNumber, destination, capacity));
            }
        } catch (NumberFormatException e) {
            throw new IOException("Ошибка формата числа при чтении файла.", e);
        } catch (InvalidFlightNumberException e) {
            throw new RuntimeException(e);
        }
    }
}

public class AirlineManagementApp extends JFrame {
    private Airline airline;
    private JTextArea flightListArea;
    private JTextField flightNumberField;
    private JTextField destinationField;
    private JTextField capacityField;

    public AirlineManagementApp() {
        airline = new Airline();
        setTitle("Управление Авиакомпанией");
        setSize(500, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(4, 2));

        inputPanel.add(new JLabel("Номер рейса:"));
        flightNumberField = new JTextField();
        inputPanel.add(flightNumberField);

        inputPanel.add(new JLabel("Направление:"));
        destinationField = new JTextField();
        inputPanel.add(destinationField);

        inputPanel.add(new JLabel("Вместимость:"));
        capacityField = new JTextField();
        inputPanel.add(capacityField);

        JButton addButton = new JButton("Добавить рейс");
        addButton.addActionListener(new AddFlightListener());
        inputPanel.add(addButton);

        JButton saveButton = new JButton("Сохранить в файл");
        saveButton.addActionListener(new SaveToFileListener());
        inputPanel.add(saveButton);

        add(inputPanel, BorderLayout.NORTH);

        flightListArea = new JTextArea();
        flightListArea.setEditable(false);
        add(new JScrollPane(flightListArea), BorderLayout.CENTER);
    }

    private class AddFlightListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String flightNumber = flightNumberField.getText();
            String destination = destinationField.getText();
            int capacity;
            try {
                capacity = Integer.parseInt(capacityField.getText());
                Flight flight = new Flight(flightNumber, destination, capacity);
                airline.addFlight(flight);
                flightListArea.append(flight.toString() + "\n");
                flightNumberField.setText("");
                destinationField.setText("");
                capacityField.setText("");
            } catch (InvalidFlightNumberException ex) {
                JOptionPane.showMessageDialog(null, ex.getMessage(), "Ошибка", JOptionPane.ERROR_MESSAGE);
            } catch (InsufficientMemoryException ex) {
                JOptionPane.showMessageDialog(null, ex.getMessage(), "Ошибка", JOptionPane.ERROR_MESSAGE);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Введите корректное значение вместимости.", "Ошибка", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private class SaveToFileListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String filename = "flights.txt";
            try {
                airline.saveToFile(filename);
                JOptionPane.showMessageDialog(null, "Рейсы успешно сохранены в " + filename);
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(null, "Ошибка при сохранении файла: " + ex.getMessage(), "Ошибка", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new AirlineManagementApp().setVisible(true);
        });
    }
}
