import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

// Класс для представления пользователей с полем email
class User {
    private String username;
    private String password;
    private String email; // Новое поле email

    public User(String username, String password, String email) {
        this.username = username;
        this.password = password;
        this.email = email;
    }

    public String getUsername() {
        return username;
    }

    public String getEmail() {
        return email;
    }
}

// Класс для представления сообщений
class Message {
    private String sender;
    private String recipient;
    private String subject;
    private String body;

    public Message(String sender, String recipient, String subject, String body) {
        this.sender = sender;
        this.recipient = recipient;
        this.subject = subject;
        this.body = body;
    }

    public String getDetails() {
        return "От: " + sender + "\nКому: " + recipient + "\nТема: " + subject + "\n\n" + body;
    }
}

public class EmailSystem extends JFrame {
    private ArrayList<User> users = new ArrayList<>();
    private ArrayList<Message> messages = new ArrayList<>();

    // Пастельные цвета
    private final Color pastelPink = new Color(255, 182, 193);
    private final Color pastelMint = new Color(152, 255, 204);

    public EmailSystem() {
        setTitle("Email System");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 1, 10, 10));
        panel.setBackground(pastelMint);

        JButton registerButton = new JButton("Регистрация пользователя");
        JButton sendMessageButton = new JButton("Отправить сообщение");
        JButton viewMessagesButton = new JButton("Просмотр сообщений");

        styleButton(registerButton);
        styleButton(sendMessageButton);
        styleButton(viewMessagesButton);

        panel.add(registerButton);
        panel.add(sendMessageButton);
        panel.add(viewMessagesButton);

        add(panel);

        registerButton.addActionListener(e -> openRegisterWindow());
        sendMessageButton.addActionListener(e -> openSendMessageWindow());
        viewMessagesButton.addActionListener(e -> openViewMessagesWindow());
    }

    private void styleButton(JButton button) {
        button.setBackground(pastelPink);
        button.setForeground(Color.DARK_GRAY);
        button.setFocusPainted(false);
    }

    private void openRegisterWindow() {
        JFrame registerFrame = new JFrame("Регистрация пользователя");
        registerFrame.setSize(300, 250);
        registerFrame.setLayout(new GridLayout(4, 2));
        registerFrame.getContentPane().setBackground(pastelMint);

        JLabel usernameLabel = new JLabel("Имя пользователя:");
        JTextField usernameField = new JTextField();
        JLabel emailLabel = new JLabel("Email:"); // Новый label для email
        JTextField emailField = new JTextField(); // Новое поле для ввода email
        JLabel passwordLabel = new JLabel("Пароль:");
        JPasswordField passwordField = new JPasswordField();
        JButton registerButton = new JButton("Зарегистрировать");
        styleButton(registerButton);

        registerFrame.add(usernameLabel);
        registerFrame.add(usernameField);
        registerFrame.add(emailLabel);         // Email сразу после имени пользователя
        registerFrame.add(emailField);
        registerFrame.add(passwordLabel);
        registerFrame.add(passwordField);
        registerFrame.add(new JLabel());
        registerFrame.add(registerButton);

        registerButton.addActionListener(e -> {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());
            String email = emailField.getText();
            users.add(new User(username, password, email));
            JOptionPane.showMessageDialog(this, "Пользователь " + username + " с email " + email + " зарегистрирован.");
            registerFrame.dispose();
        });

        registerFrame.setVisible(true);
    }

    private void openSendMessageWindow() {
        JFrame sendMessageFrame = new JFrame("Отправить сообщение");
        sendMessageFrame.setSize(400, 300);
        sendMessageFrame.setLayout(new GridLayout(5, 2));
        sendMessageFrame.getContentPane().setBackground(pastelMint);

        JLabel senderLabel = new JLabel("Отправитель:");
        JTextField senderField = new JTextField();
        JLabel recipientLabel = new JLabel("Получатель:");
        JTextField recipientField = new JTextField();
        JLabel subjectLabel = new JLabel("Тема:");
        JTextField subjectField = new JTextField();
        JLabel bodyLabel = new JLabel("Сообщение:");
        JTextArea bodyField = new JTextArea();
        JButton sendButton = new JButton("Отправить");
        styleButton(sendButton);

        sendMessageFrame.add(senderLabel);
        sendMessageFrame.add(senderField);
        sendMessageFrame.add(recipientLabel);
        sendMessageFrame.add(recipientField);
        sendMessageFrame.add(subjectLabel);
        sendMessageFrame.add(subjectField);
        sendMessageFrame.add(bodyLabel);
        sendMessageFrame.add(bodyField);
        sendMessageFrame.add(new JLabel());
        sendMessageFrame.add(sendButton);

        sendButton.addActionListener(e -> {
            String sender = senderField.getText();
            String recipient = recipientField.getText();
            String subject = subjectField.getText();
            String body = bodyField.getText();
            messages.add(new Message(sender, recipient, subject, body));
            JOptionPane.showMessageDialog(this, "Сообщение отправлено.");
            sendMessageFrame.dispose();
        });

        sendMessageFrame.setVisible(true);
    }

    private void openViewMessagesWindow() {
        JFrame viewMessagesFrame = new JFrame("Просмотр сообщений");
        viewMessagesFrame.setSize(400, 300);
        viewMessagesFrame.setLayout(new BorderLayout());
        viewMessagesFrame.getContentPane().setBackground(pastelMint);

        JTextArea messagesArea = new JTextArea();
        messagesArea.setEditable(false);

        for (Message message : messages) {
            messagesArea.append(message.getDetails() + "\n\n");
        }

        JScrollPane scrollPane = new JScrollPane(messagesArea);
        viewMessagesFrame.add(scrollPane, BorderLayout.CENTER);
        viewMessagesFrame.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            EmailSystem emailSystem = new EmailSystem();
            emailSystem.setVisible(true);
        });
    }
}
