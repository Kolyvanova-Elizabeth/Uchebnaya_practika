import java.util.*;

class Circle {
    private double x;
    private double y;
    private double radius;

    public Circle(double x, double y, double radius) {
        if (radius <= 0) {
            throw new IllegalArgumentException("Радиус должен быть положительным числом.");
        }
        this.x = x;
        this.y = y;
        this.radius = radius;
    }

    public double getArea() {
        return Math.PI * radius * radius;
    }

    public double getPerimeter() {
        return 2 * Math.PI * radius;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    @Override
    public String toString() {
        return "Окружность с центром (" + x + ", " + y + ") и радиусом " + radius;
    }

    public boolean isOnSameLine(Circle other) {
        return this.x == other.x || this.y == other.y;
    }
}

public class CircleMain {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Введите количество окружностей: ");
        int n = scanner.nextInt();

        Circle[] circles = new Circle[n];
        for (int i = 0; i < n; i++) {
            System.out.print("Введите координаты центра (x, y) и радиус окружности " + (i + 1) + ": ");
            double x = scanner.nextDouble();
            double y = scanner.nextDouble();
            double radius = scanner.nextDouble();
            circles[i] = new Circle(x, y, radius);
        }

        System.out.println("\nГруппы окружностей с центрами на одной прямой:");
        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                if (circles[i].isOnSameLine(circles[j])) {
                    System.out.println(circles[i] + " и " + circles[j] + " лежат на одной прямой.");
                }
            }
        }

        Circle maxAreaCircle = circles[0];
        Circle minAreaCircle = circles[0];
        for (Circle circle : circles) {
            if (circle.getArea() > maxAreaCircle.getArea()) {
                maxAreaCircle = circle;
            }
            if (circle.getArea() < minAreaCircle.getArea()) {
                minAreaCircle = circle;
            }
        }

        Circle maxPerimeterCircle = circles[0];
        Circle minPerimeterCircle = circles[0];
        for (Circle circle : circles) {
            if (circle.getPerimeter() > maxPerimeterCircle.getPerimeter()) {
                maxPerimeterCircle = circle;
            }
            if (circle.getPerimeter() < minPerimeterCircle.getPerimeter()) {
                minPerimeterCircle = circle;
            }
        }

        System.out.println("\nОкружность с наибольшей площадью: " + maxAreaCircle);
        System.out.println("Окружность с наименьшей площадью: " + minAreaCircle);
        System.out.println("Окружность с наибольшим периметром: " + maxPerimeterCircle);
        System.out.println("Окружность с наименьшим периметром: " + minPerimeterCircle);

        scanner.close();
    }
}
