import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

class Symbol {
    private char symbol;

    public Symbol(char symbol) {
        this.symbol = symbol;
    }

    public char getSymbol() {
        return symbol;
    }
}

class Word {
    private String word;

    public Word(String word) {

        this.word = word.trim().replaceAll("\\s+", " ");
    }

    public String getWord() {
        return word;
    }

    public int countLetterOccurrences(char letter) {
        int count = 0;
        for (char c : word.toCharArray()) {
            if (Character.toLowerCase(c) == Character.toLowerCase(letter)) {
                count++;
            }
        }
        return count;
    }
}

class Sentence {
    private List<Word> words;

    public Sentence(String sentence) {
        words = new ArrayList<>();
        String[] wordArray = sentence.split("\\s+"); // Разделение предложения на слова
        for (String wordStr : wordArray) {
            if (!wordStr.isEmpty()) {
                words.add(new Word(wordStr));
            }
        }
    }

    public List<Word> getWords() {
        return words;
    }
}

class Paragraph {
    private List<Sentence> sentences;

    public Paragraph(String paragraph) {
        sentences = new ArrayList<>();
        String[] sentenceArray = paragraph.split("(?<=[.!?])\\s+"); // Разделение на предложения
        for (String sentenceStr : sentenceArray) {
            if (!sentenceStr.trim().isEmpty()) {
                sentences.add(new Sentence(sentenceStr.trim()));
            }
        }
    }

    public List<Sentence> getSentences() {
        return sentences;
    }
}

class TextProcessor {
    private List<Word> words;

    public TextProcessor(String text) {
        words = new ArrayList<>();
        String[] paragraphArray = text.split("\\n\\n"); // Разделение на абзацы
        for (String paragraphStr : paragraphArray) {
            Paragraph paragraph = new Paragraph(paragraphStr.trim());
            for (Sentence sentence : paragraph.getSentences()) {
                words.addAll(sentence.getWords());
            }
        }
    }

    public List<Word> getWords() {
        return words;
    }

    public List<Word> sortWordsByLetter(char letter) {
        Collections.sort(words, new Comparator<Word>() {
            @Override
            public int compare(Word w1, Word w2) {
                int count1 = w1.countLetterOccurrences(letter);
                int count2 = w2.countLetterOccurrences(letter);

                if (count1 == count2) {
                    return w1.getWord().compareToIgnoreCase(w2.getWord());
                }
                return Integer.compare(count1, count2); // Сортировка по количеству
            }
        });
        return words;
    }
}

public class TextSorterApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Введите текст (для завершения ввода введите 'exit'):");
        StringBuilder textBuilder = new StringBuilder();
        String line;
        while (!(line = scanner.nextLine()).equals("exit")) {
            textBuilder.append(line).append("\n");
        }
        String text = textBuilder.toString().trim();

        System.out.println("Введите букву для сортировки:");
        char letter = scanner.nextLine().charAt(0);

        TextProcessor processor = new TextProcessor(text);
        List<Word> sortedWords = processor.sortWordsByLetter(letter);

        System.out.println("Сортированные слова:");
        for (Word word : sortedWords) {
            System.out.println(word.getWord());
        }

        scanner.close();
    }
}
